C.A. Gatintas es una fuente sans, experimental, sucia y degradada, realizada en un ejercicio de deconstruccion violento y descuidado, en ella se puede ver el paso del tiempo y sus cicatrices, la huella de elementos naturales y otros que no lo son, un sumo proceso de bio degradaciÛn tipografica...
Números disponibles en mi web / Numbers available on my website
Thank you for your interest in my font :) This font is free for personal use only.
If you are interested in commercial use, you can buy the license in defharo.com

You may redistribute my fonts on your site as long as credit is as the original author. Donations are always welcome :)
